/*var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'radar',
    data: {
        labels: ['LTP', 'CHANGE', 'YCP', 'Price', 'Amount'],
        datasets: [{
                label: 'RECKITTBEN',
                data: [45.3, 7.60, 50.65, 23, 45],
                backgroundColor: 'rgb(80, 125, 161, 0.5)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }, {
                label: 'MARICO',
                data: [20, -7.70, 90, 45, 66],
                backgroundColor: 'rgb(87, 114, 38, 0.5)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            },
            {
                label: 'Partho',
                data: [20, -10.70, 50, 5, 100],
                backgroundColor: 'rgb(219, 22, 55, 0.8)',
                borderColor: 'rgb(219, 22, 55, 1)',
                borderWidth: 1
            }
        ]
    },
    options: {}
});*/

var table = document.getElementById('dataTable');
var json = []; // First row needs to be headers 
var headers = [];
for (var i = 0; i < table.rows[0].cells.length; i++) {
    headers[i] = table.rows[0].cells[i].innerHTML.toLowerCase().replace(/ /gi, '');
}

// Go through cells 
for (var i = 1; i < table.rows.length; i++) {
    var tableRow = table.rows[i];
    var rowData = {};
    for (var j = 0; j < tableRow.cells.length; j++) {
        rowData[headers[j]] = tableRow.cells[j].innerHTML;
    }

    json.push(rowData);
}

//console.log(json);

var labels = json.map(function(e) {
    return e.tradingcode;
});
//console.log(labels); // ["2016", "2017", "2018", "2019"]

// Map JSON values back to values array
var values = json.map(function(e) {
    return e.change;
});
//console.log(ltp);