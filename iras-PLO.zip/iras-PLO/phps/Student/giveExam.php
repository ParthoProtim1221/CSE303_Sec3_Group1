<?php
include '../../connection.php';
$sem = $_SESSION['semester']; // current semester
$y = $_SESSION['year']; // current year
$id = $_SESSION['id']; //student id

$assessmentID = isset($_POST['assessmentID']) ? $_POST['assessmentID'] : null; // assessment id


date_default_timezone_set("Indian/Chagos");
$asd = date('d M Y');

echo "Exam Starting time ";
echo date('D M d Y H:i:s:O');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <!-- <script src="../../scripts/repeater.js"></script> -->
    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>


</head>

<body>

    <br>
    
    <p id="demo" style="text-align: center; font-size: 60px; margin-top: 1vh;"><strong></strong></p>

    <form action="submitAnswer.php" id="contentLoader1div" class="questionForm" method="POST" enctype="multipart/form-data">
        <!--<label style="align-items: center;">Available PLOs for the course: </label>-->
        <?php 
        // $q = "SELECT * FROM assessment AS a, section AS s WHERE a.assessmentID = '$assessmentID' AND a.enrollmentID = s.enrollmentID ";
        $q = "SELECT * FROM assessment AS a, section AS s, question AS q WHERE a.assessmentID = '$assessmentID' AND a.enrollmentID = s.enrollmentID AND q.assessmentID = a.assessmentID";
        $query = mysqli_query($con,$q);
        $t = $query->fetch_assoc();
        ?>
        <h5 style="text-align: center;">Course ID : <?php echo $t['courseID']; ?></h5>
        <h5 style="text-align: center;">Section : <?php echo $t['sectionID']; ?></h5>
        <h5 style="text-align: center;">Exam Type : <?php echo $t['nameOfAss']; ?></h5>
        <h5 style="text-align: center;">Total Marks : <?php echo $t['totalMarks']; ?></h5>

        <div class="input_fields_wrap">
            <div class="row ansSection">
                <div class="col-md-11">

                    <?php
                    echo '<input type="hidden" name="enrollmentID" value = "'.$t['enrollmentID'].'">'; 
                    $query = mysqli_query($con,$q);
                    $x = 1;
                    while($t = $query->fetch_assoc()){

                        echo '&nbsp&nbsp&nbsp
                        <h4 style = "color: skyblue;" align = "center" name="myAnswers[]" id="course_description" required>
                        <input type="hidden" name="quesID[]" value = "'.$t['quesID'].'"> 
                        <strong>This is Question No. ' . $x . '</strong></h4>
                        <p>'.$t['details'].'</p>
                        <textarea name="myfile[]" id="course_description" required placeholder="Write down Your Answer"></textarea> <br><br>';
                    $x++;
                    
                    }
                    ?>
                </div>
            </div>
        </div>

        <div align="center">
            <input type="submit" id="lockSubmit" style="width: 20%; height: 5vh;" class="btn btn-primary text-white shadow" value="Submit" /> 
            <a href="dashboard_Student.php"><button type="button"  style="width: 20%; height: 5vh;" class="btn btn-primary text-white shadow" >Cancel</button></a>
        </div>
    </form>


    <script src="../../scripts/jquery.min.js"></script>




    <script>
        // Set the date we're counting down to
        //var countDownDate = new Date();
        var countDownDate = new Date(Date.parse('<?php echo $asd; ?>'));
        //var countDownDate = new Date(Date.parse("18 May 2021"));
        console.log(countDownDate);
        countDownDate = new Date();
        //var countDownDate = new Date();
        //countDownDate.setMinutes(countDownDate.getMinutes() + 2);
        countDownDate.setSeconds(countDownDate.getSeconds() + 50);

        // Update the count down every 1 second
        var x = setInterval(function() {

            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds

            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = hours + "h " + minutes + "m " + seconds + "s ";

            if (hours == 0) {
                if (minutes == 0) {
                    document.getElementById("demo").innerHTML = seconds + "s ";
                } else {
                    document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
                }
            }


            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "Exam Time is Over!";
                document.getElementById("demo").style.color = "red";
                document.getElementById("lockSubmit").disabled = true;
                document.getElementById("lockSubmit").value = "Submission Time is Over!";
                document.getElementById("lockSubmit").style.backgroundColor = "red";
            }
        }, 1000);
    </script>

    <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>