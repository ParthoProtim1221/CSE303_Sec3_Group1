<?php
    include 'connection.php';
    $ycpArr = Array();
    $structure = isset($_POST['select']) ? $_POST['select'] : null;
    for($i=0;$i<=4;$i++){
        $select = "SELECT SUM(obatinMarks)*100 / SUM(q.mark) AS plo 
                   FROM evaluation AS e, question AS q,student AS s 
                   WHERE e.studenID=s.studentID AND e.quesID = q.quesID AND q.coID LIKE '{$i}%' 
                         AND q.assessmentID LIKE '%CSE203+L_1_Summer_2021%'";
        $result = mysqli_query($con,$select);
        while($travese = $result->fetch_assoc()){
          // array_push($ycpArr, $travese['total']);
          // array_push($ycpArr1, $travese['programID']);
          $ycpArr[$i][0]="co".$i;
          $ycpArr[$i][1]=$travese['plo'];
          $i++;
          
      }
    } 
    ?>
<script>
    var obj = <?php echo json_encode($ycpArr); ?>;
    
</script>
<?php echo json_encode($ycpArr); ?>

<script type="text/javascript">
//var obj = <?php echo json_encode($ycpArr); ?>;
    // var my_2d = [["PLO5","89"],["PLO1","69"],["PLO2","87"],["PLO3","75"],["PLO4","57"],["ASP","70"]]
    // var my_2d = [["PLO1","89"],["PLO2","69"],["PLO3","77"],["PLO4","57"]]
    var obj = <?php echo json_encode($ycpArr); ?>;
      google.charts.load('current', {'packages':['corechart']});

      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Course');
        data.addColumn('number', 'PLO-Achievement');
        for(i = 0; i < obj.length; i++)
            data.addRow([obj[i][0],parseInt(obj[i][1])]);
        // Set chart options
        var options = {'title':'Course wise Performance',
                       'width':600,
                       'height':500,
			   is3D:true,};


        var chart = new google.visualization.<?php echo $structure ;?>(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
	
</script>

</div>
 <section>
    <div class="container">
        <div class = "row">
            <div class="col-lg-6 px-5 mr-3" align="center">
               <div id="chart_div"></div>
            </div>
        </div>
    </div>
</section>