<?php
    include '../../connection.php';
    $sem = $_SESSION['semester'];
    $y = $_SESSION['year'];
    $id = $_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../Faculty/facultyStyle.css">

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script>
    <style>

    </style>

</head>

<body>


    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Home</a>


        <div class="dropDownWrapper">
            <select id="graph" class="form-select">
                <option selected disabled> <i>Statistics </i></option>
                <option value="first"> Students Enrolled</option>
                <option value="second"> Peformance On CGPA</option>
                <option value="third"> Peformance On GPA</option>
                <option value="fourth"> PLO Mapping</option>
                <option value="course"> Course Information </option>
            </select>
        </div> &nbsp 
        
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            &nbsp &nbsp
            <!-- <a href="ploMapping.php"><button type="button" class="btn btn-success">Map PLO</button></a> &nbsp &nbsp  -->
            
            <a href="#"><button type="button" class="btn btn-success">CQI Reports</button></a>
            <p> &nbsp</p>
            <ul class="navbar-nav ml-auto">
                <p align="right"> <?php echo $_SESSION['name']; ?> <br> Independent University, Bangladesh</p>
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
        
    </nav>

    <div class="graphContainer">
        <div id="first" class="data">
            <form action="studentPerformace.php" id="form"method="POST" align="center">
                <h3 style="text-align: center;">Select year </h3> <br>
                <select name="year" style="width:35%; padding:5px" required>
                    <option selected disabled>Select Year </option>
                    
                <?php
                    
                    $q = "SELECT distinct year from student";
                    $query = mysqli_query($con, $q);
                    while($travese = mysqli_fetch_array($query)){
                        echo "<option value = ".$travese['year'] .">".$travese['year']."</option>";
                    }
                ?>
                </select> <br>     <br>                

                <div class="align-center">
                    <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
                </div>
            </form>
            <br> <br>
            <div align="center">
                <button type="button" class="btn btn-primary"> <a href="schoolWiseStudentEnrollment.php" style="color:white;">School Wise Student Enrollment Grpah</a></button> &nbsp
                <button type="button" class="btn btn-primary"> <a href="programWiseStudentEnrollment.php"  style="color:white;">Program Wise Student Enrollment Grpah</a></button> &nbsp
                <button type="button" class="btn btn-primary"> <a href="departmentWiseStudentEnrollment.php" style="color:white;">Department Wise Student Enrollment Grpah</a></button>
            </div>

        </div>

        <div id="second" class="data">
                <canvas id="myChart2" style="width: 500px"></canvas>
        </div>

        <div id="third" class="data">
                <canvas style="width: 500px" id="myChart3"></canvas>
        </div>

        <div id="fourth" class="data">
            <br> <br>
            <form action="ploMapping.php" id="form" method="POST" align="center">
                <h2>Select The courses for PLO Set-UP</h2> <br> <br>
                <select name="cou" style="width:35%; padding:5px">
                    <option selected disabled>Select Course</option>
                    
                <?php
                    $q = "SELECT distinct c.courseID AS course, c.courseName AS nam FROM course AS c 
                            WHERE c.courseID NOT IN (SELECT distinct p.courseID FROM ploinitialmapping AS p)";

                    $query = mysqli_query($con, $q);
                    while($travese = mysqli_fetch_array($query)){
                        echo "<option value = ".$travese['course'] .">".$travese['nam']."</option>";
                    }
                ?>
                </select> <br>     <br>       

                <div class="align-center">
                    <input type="submit" id="form1" name="insert" class="btn but1 btn-primary text-white shadow" value="Submit" onclick="setValue()"/>
                </div>
            </form>
        </div>
        <div id="course" class="data">
            <br> <br>
            <form action="../Faculty/facultyCourseInformation.php" id="form" method="POST" align="center">
                <h2>Select courses </h2> <br> <br>
                <select name="course" style="width:35%; padding:5px">
                    <option selected disabled>Select Course</option>
                    
                <?php
                    $q = "SELECT * from section WHERE facultyID = '$id' AND year = '$y' AND semester = '$sem'";
                    $query = mysqli_query($con, $q);
                    while($travese = mysqli_fetch_array($query)){
                        echo "<option value = ".$travese['enrollmentID'] .">".$travese['courseID']."&nbsp &nbsp Section ".$travese['sectionID']."</option>";
                    }
                ?>
                </select> <br>     <br>       

                <div class="align-center">
                    <input type="submit" class="btn but1 btn-primary text-white shadow" value="Submit" />
                </div>
            </form>
        </div>

    </div>



    <script src="../../scripts/jquery.min.js"></script>    
    <script src="../../scripts/Chart.js"></script>
    <script>
        $(document).ready(function() {
            $("#graph").on('change', function() {
                //alert($(this).val());
                $(".data").hide();
                $("#" + $(this).val()).fadeIn(700);
            }).change();
        });



    </script>
</body>

</html>