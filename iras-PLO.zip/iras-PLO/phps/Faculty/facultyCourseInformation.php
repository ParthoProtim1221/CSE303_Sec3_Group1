<?php
include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id'];

if (isset($_POST['course'])) {
    $c = $_POST['course'];
} else {
    $arr =  $_SESSION['array'];
    if (isset($arr[4])) {
        $c = $arr[4];
    } else {
        $c = $_SESSION['course'];
    }
}
// there is course id in $c
$_SESSION['course'] = $c;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Information</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">


    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script>
    <link rel="stylesheet" href="course.css">
    <style>
        #stime:hover {
            cursor: pointer;
        }

        .tableStyle {
            background-color: whitesmoke;
            height: auto;
            display: block;
            margin: 20vh;
            border: 5px solid #746cc0;
            padding: 2%;
        }
    </style>

</head>

<body>


    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <?php
        $q = "SELECT * FROM section WHERE enrollmentID = '$c'";
        $query = mysqli_query($con, $q);
        $travese = mysqli_fetch_array($query);
        $enrollment = $travese['enrollmentID'];
        ?>
        <p align="left"> <?php echo "Course ID: " . $travese['courseID']; ?>
            <br> <?php echo "Semester : " . $travese['semester']; ?> <br>
            <?php echo "Section : " . $travese['sectionID']; ?>
            &nbsp <?php echo "Year : " . $travese['year']; ?> <br>

        </p>
        &nbsp &nbsp &nbsp &nbsp
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="dropDownWrapper">
                <select id="graph" class="form-select">
                    <option selected disabled> <i> Course </i></option>
                    <option value="co"> Set Course Outcome </option>
                    <option value="questionPaper"> Set Question Paper </option>
                    <option value="evaluation"> Student's Evaluation </option>
                    <option value="attandence"> Student Attandence </option>
                    <option value="cqi"> CQI Report </option>
                    <option value="instractorWise"> Instractor Wise Report </option>
                </select>
            </div> &nbsp
            &nbsp &nbsp
            <ul class="navbar-nav ml-auto">
                <p align="right"> <?php echo $_SESSION['name']; ?> <br> Independent University, Bangladesh</p>
                <div class="navbar-text ml-lg-3">
                    <?php
                    $qq = "SELECT * FROM department AS d WHERE d.facultyIDInCharge = '$id'";
                    $qw = mysqli_query($con, $qq);
                    $qw = mysqli_fetch_assoc($qw);
                    if ($qw != null) {
                    ?>
                        <a href="../Head/dashboard_head.php" class="btn but1 btn-primary text-white shadow">Back</a>
                    <?php } else {
                    ?>
                        <a href="../Faculty/dashboard_Faculty.php" class="btn but1 btn-primary text-white shadow">Back</a>
                    <?php } ?>

                </div>
            </ul>
        </div>

    </nav>

    <div class="graphContainer">
        <div id="co" class="data">
            <?php
            $q1 = "SELECT * FROM co WHERE enrollmentID = '$enrollment'";
            $qu = mysqli_query($con, $q1);
            if (mysqli_num_rows($qu) == 0) {
            ?>
                <form action="setCourseOutcome.php" id="contentLoader1div" class="content1" method="POST">
                    <div class="courseOutcome">
                        <h5 style="text-align: center;"> Available PLO For this Course:
                            <?php
                            $cou = $travese['courseID'];
                            $q = "SELECT * FROM ploinitialmapping WHERE courseID = '$cou'";
                            $query = mysqli_query($con, $q);
                            $arr = array();

                            $i = 0;
                            while ($travese = mysqli_fetch_array($query)) {
                                $arr[$i] = $travese['ploID'];
                                echo "PLO-" . $travese['ploID'] . " &nbsp";
                                $i++;
                            }
                            $arr[4] = $enrollment;
                            echo '<input type ="hidden" name="enroll" value=' . $enrollment . ' >';
                            $_SESSION['array'] = $arr;
                            ?>
                        </h5>

                        <div class="input_fields_wrap">
                            <?php
                            $q1 = "SELECT * FROM course WHERE courseID = '$cou'";
                            $query1 = mysqli_query($con, $q1);
                            $travese1 = mysqli_fetch_array($query1);
                            $description = $travese1['courseDescription'];
                            ?>
                            <div class="row CLO_Div">
                                <div class="col-md-11">
                                    <?php

                                    $query = mysqli_query($con, $q);
                                    while ($travese = mysqli_fetch_array($query)) {
                                        echo "PLO-" . $travese['ploID'] . ": &nbsp";
                                        $p = $travese['ploID'];
                                        $a = "SELECT * FROM plo WHERE ploID = '$p'";
                                        $qqq = mysqli_query($con, $a);
                                        $ttt = mysqli_fetch_array($qqq);
                                        echo "<b>" . $ttt['name'] . "</b> &nbsp &nbsp" . $ttt['details'];
                                        echo "<br>";
                                    }
                                    ?>
                                    <hr>
                                    <label for="course_description">
                                        <p><b>Course Description: </b> <?php echo $description; ?> </p>
                                    </label>

                                    <?php
                                    $query = mysqli_query($con, $q);
                                    $travese = mysqli_fetch_array($query);
                                    $plo1 = $travese['ploID'];
                                    $travese = mysqli_fetch_array($query);
                                    $plo2 = $travese['ploID'];
                                    $travese = mysqli_fetch_array($query);
                                    $plo3 = $travese['ploID'];
                                    $travese = mysqli_fetch_array($query);
                                    $plo4 = $travese['ploID'];
                                    ?>
                                    PLO- <?php echo $plo1 ?> is being used for Course OutCome 1. Write Down the detaia of Course Outcome 1 &nbsp
                                    <input type="text" id="name" name="name1" style="width:35%;padding: 5px;" required placeholder="For course Outcome 1 "> <br> <br>
                                    PLO- <?php echo $plo2 ?> is being used for Course OutCome 2. Write Down the detaia of Course Outcome 2 &nbsp
                                    <input type="text" id="name" name="name2" style="width:35%;padding: 5px;" required placeholder="For course Outcome 2 "> <br> <br>
                                    PLO- <?php echo $plo3 ?> is being used for Course OutCome 3. Write Down the detaia of Course Outcome 3 &nbsp
                                    <input type="text" id="name" name="name3" style="width:35%;padding: 5px;" required placeholder="For course Outcome 3 "> <br> <br>
                                    PLO- <?php echo $plo4 ?> is being used for Course OutCome 4. Write Down the detaia of Course Outcome 4 &nbsp
                                    <input type="text" id="name" name="name4" style="width:35%;padding: 5px;" required placeholder="For course Outcome 4 "> <br> <br>

                                </div>

                            </div>
                        </div>

                        <div align="right">
                            <!-- <a href="#" id="saveID" class="btn btn-primary text-white shadow">Submit</a> -->
                            <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
                        </div>
                    </div>
                </form>
            <?php
            } else {
            ?>
                <div id="#" class="#">
                    <br> <br>
                    <p><strong><i>You have already set the course outcome for this course. The course outcomes for this course are as follows:</i></strong></p>
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Course Outome</th>
                                <th>Description</th>
                                <th>Mapped PLOs</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $q = "SELECT c.coID AS co, c.description AS descrip, p.ploID AS plo FROM co AS c
                                INNER JOIN plocomapping AS p ON p.coID = c.coID AND enrollmentID = '$enrollment'";
                            $query = mysqli_query($con, $q);
                            while ($t = mysqli_fetch_array($query)) {
                                $c = $t['co'];
                                $c = substr($c, 0, 1);
                            ?>

                                <tr>
                                    <td><?php echo $c; ?></td>
                                    <td><?php echo $t['descrip']; ?></td>
                                    <td><?php echo $t['plo']; ?></td>
                                </tr>
                            <?php }

                            ?>
                        </tbody>
                    </table>
                </div>
            <?php } ?>

        </div>

        <div id="evaluation" class="data tableStyle">
            <form action="../Faculty/mark_Exam2.php" id="form" method="POST" align="center">
                <h2>Select Exam Type </h2> <br> <br>
                <?php
                $c = $_SESSION['course'];
                ?>
                <select name="loadExam" style="width:35%; padding:5px">
                    <option selected disabled>Select The type of Exam</option>

                    <?php

                    $q = "SELECT DISTINCT a.nameOfAss as noa FROM assessment AS a, question AS q, evaluation AS e WHERE a.assessmentID = q.assessmentID AND q.quesID = e.quesID AND e.enrollmentID = '$c'";
                    $query = mysqli_query($con, $q);
                    while ($travese = $query->fetch_assoc()) {
                        echo $travese['noa'];
                        echo "<option value = " . $travese['noa'] . ">" . $travese['noa'] . "</option>";
                    }
                    ?>
                </select> <br> <br>

                <div class="align-center">
                    <input type="submit" class="btn but1 btn-primary text-white shadow" value="Submit" />
                </div>
            </form>
        </div>
        <div id="cqi" class="data">
            <?php
            $q = "SELECT e.studentID AS stud, SUM(obatinMarks)*100 / SUM(q.mark) as co FROM student AS s, registration AS r , question AS q, evaluation AS e WHERE e.evaluationID LIKE '%$c%' AND e.studentID = s.studentID AND e.quesID = q.quesID AND q.coID LIKE '1%'";
            $q = mysqli_query($con, $q);
            while ($t = $q->fetch_assoc()) {
                $value = $t['co'];
                $stud = $t['stud'];
                $tt = "UPDATE registration AS r
                    SET CO1 = $value; 
                    WHERE r.enrollmentID = '$c' AND r.studentID = '$stud'";
                mysqli_query($con, $tt);
            }
            $q = "SELECT e.studentID AS stud, SUM(obatinMarks)*100 / SUM(q.mark) as co FROM student AS s, registration AS r , question AS q, evaluation AS e WHERE e.evaluationID LIKE '%$c%' AND e.studentID = s.studentID AND e.quesID = q.quesID AND q.coID LIKE '2%'";
            $q = mysqli_query($con, $q);
            while ($t = $q->fetch_assoc()) {
                $value = $t['co'];
                $stud = $t['stud'];
                $tt = "UPDATE registration AS r
                    SET CO2 = $value; 
                    WHERE r.enrollmentID = '$c' AND r.studentID = '$stud'";
                mysqli_query($con, $tt);
            }
            $q = "SELECT e.studentID AS stud, SUM(obatinMarks)*100 / SUM(q.mark) as co FROM student AS s, registration AS r , question AS q, evaluation AS e WHERE e.evaluationID LIKE '%$c%' AND e.studentID = s.studentID AND e.quesID = q.quesID AND q.coID LIKE '3%'";
            $q = mysqli_query($con, $q);
            while ($t = $q->fetch_assoc()) {
                $value = $t['co'];
                $stud = $t['stud'];
                $tt = "UPDATE registration AS r
                    SET CO3 = $value; 
                    WHERE r.enrollmentID = '$c' AND r.studentID = '$stud'";
                mysqli_query($con, $tt);
            }
            $q = "SELECT e.studentID AS stud, SUM(obatinMarks)*100 / SUM(q.mark) as co FROM student AS s, registration AS r , question AS q, evaluation AS e WHERE e.evaluationID LIKE '%$c%' AND e.studentID = s.studentID AND e.quesID = q.quesID AND q.coID LIKE '4%'";
            $q = mysqli_query($con, $q);
            while ($t = $q->fetch_assoc()) {
                $value = $t['co'];
                $stud = $t['stud'];
                $tt = "UPDATE registration AS r
                    SET CO4 = $value; 
                    WHERE enrollmentID = '$c' AND studentID = '$stud'";
                mysqli_query($con, $tt);
            }


            $q = "SELECT SUM(CO1) * 100 / COUNT(CO1) as co FROM registration GROUP BY CO1";
            $q = mysqli_query($con, $q);
            $t = $q->fetch_assoc();
            echo "CO1 % -> " . $t['co'] . "<br>";
            $q = "SELECT SUM(CO2) * 100 / COUNT(CO2) as co FROM registration GROUP BY CO2";
            $q = mysqli_query($con, $q);
            $t = $q->fetch_assoc();
            echo "CO2 % -> " . $t['co'] . "<br>";
            $q = "SELECT SUM(CO3) * 100 / COUNT(CO3) as co FROM registration GROUP BY CO3";
            $q = mysqli_query($con, $q);
            $t = $q->fetch_assoc();
            echo "CO3 % -> " . $t['co'] . "<br>";
            $q = "SELECT SUM(CO4) * 100 / COUNT(CO4) as co FROM registration GROUP BY CO4";
            $q = mysqli_query($con, $q);
            $t = $q->fetch_assoc();
            echo "CO4 % -> " . $t['co'];

            ?>
        </div>
        <div id="instractorWise" class="data content1" style="position: relative; padding: 2%;">
            <?php include '../../connection.php'; ?>
        </div>
        <div id="attandence" class="data content1" style="position: relative; padding: 2%;">
            <form action="#" method="POST">
                <p><strong><i>Student Attandence</i></strong></p>
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th>Select Student </th>
                            <th>Student ID</th>
                            <th>Student Name </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $q = "SELECT * FROM student AS s, registration AS r WHERE r.enrollmentID = '$c' AND r.studentID = s.studentID";
                        $query = mysqli_query($con, $q);
                        $i = 0;
                        while ($t = $query->fetch_assoc()) {
                            echo '<td><input type="checkbox" name = "studentAttandence[]" value = ' . $i . ' style = "width: 3vh; height: 3vh;"></td>
                        <input type="hidden" name = "enrollmentID[]" value=' . $t['studentID'] . '>
                        <td>' . $t['studentID'] . '</td>
                        <td>' . $t['fname'] . " " . $t['lname'] . '</td>
                        </tr>';
                        }
                        ?>
                    </tbody>
                </table>
                <div align="right">
                    <input type="submit" style="width: 10%;" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
                </div>
            </form>
        </div>
    </div>





    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>
    <script>
        $(document).ready(function() {
            $("#graph").on('change', function() {
                //alert($(this).val());
                if ($(this).val() == "questionPaper")
                    window.location = 'makeQuestions.php';
                else {
                    $(".data").hide();
                    $("#" + $(this).val()).fadeIn(700);
                }
            }).change();
        });

        $(document).ready(function() {
            var x = 2; //initlal text box count
            var max_fields = 6; //maximum input boxes allowed
            var wrapper = $(".input_fields_wrap"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID


            var b = '"><div class="col-md-11"><label for="course_description">Write the course description below in details. Note: The following CO will be saved as CO- ';
            var c = '<p id="CLO_current_number"></p></label><textarea name="mytext[]" id="course_description" required></textarea>';
            var d = '</div><button class = "remove_field" align="right" id="closer"></button></div>';


            $(add_button).click(function(e) { //on add input button click
                e.preventDefault();

                if (x <= max_fields) { //max input box allowed

                    //text box increment

                    var PLOArr = []

                    for (var i = 1; i <= 12; i++) {

                        PLOArr.push('&nbsp&nbsp<input type="checkbox" id = "' + x + i + '"name = "PLO_CO' + x + '[]" value = "PLO-' + i + '">');
                        PLOArr.push('<label for = "' + x + i + '">&nbspPLO-' + i + '</label>');

                    }

                    var a = '<div class="row CLO_Div" id = "list' + x;

                    $(wrapper).append(a + b + x + c + PLOArr.join("") + d);
                    //$(wrapper).append(x);

                    x++;
                }
            });


            $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
                e.preventDefault();

                if (x > 3) {
                    var newItem = document.createElement('BUTTON');
                    newItem.id = "closer";
                    newItem.className = "remove_field";


                    //var newX = x - 2;
                    str = "list" + (x - 2).toString();
                    var list = document.getElementById(str);

                    list.insertBefore(newItem, list.childNodes[1]);
                }

                $(this).parent('div').remove();


                if (x >= 2) {
                    x--;
                } else {
                    x = 1;
                }
            })
        });


        $(document).ready(function() {
            $("#course_dropDown").on('change', function() {

                $(".data").hide();
                //var courseSelectedNode = document.getElementById("course_dropDown");
                var courseSelected = document.getElementById("course_dropDown").value;
                $(".data").attr("id", courseSelected);
                $("#" + $(this).val()).fadeIn(700);
            }).change();
        });

        $(function() {
            $(".but").on("click", function(e) {
                e.preventDefault();
                $(".content1").hide();
                $("#" + this.id + "div").fadeIn(700);
            });
        });
    </script>
</body>

</html>