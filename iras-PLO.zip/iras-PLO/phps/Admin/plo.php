<?php
    include '../../connection.php';

    $program =  $_POST['program'];
    $plo =  $_POST['plo'];
    $name =  $_POST['name'];
    $details =  $_POST['details'];
    $ploLevel =  $_POST['ploLevel'];
    
    
    $insert = "INSERT INTO plo(ploID,name,deatails,lavel,programID) 
                values('$plo','$name','$details','$ploLevel','$program')";
	mysqli_query($con, $insert);

?>
<script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>