<?php
include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$i=1;

while($i<5)
$qq = "SELECT * FROM registration";
$qq = mysqli_query($con,$qq);
while($tt = $qq->fetch_assoc())
{
    $sid = $tt['studentID'];
    $enroll = $tt['enrollmentID'];
    $q = "SELECT SUM(obatinMarks)*100 / SUM(q.mark) AS mark FROM evaluation AS e, question AS q, registration AS r WHERE e.evaluationID LIKE '$sid%' AND e.quesID = q.quesID AND q.coID LIKE '$i%' AND q.assessmentID LIKE '%$enroll%'";
    $q = mysqli_query($con, $q);
    while($t = $q->fetch_assoc())
    {
        echo $sid." ".$enroll." ".$t['mark']."<br>";
    }
    $i++;
}
