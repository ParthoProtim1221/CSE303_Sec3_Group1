<?php
    $con = mysqli_connect('localhost','root');
    mysqli_select_db($con, 'spm');

	$uName=null;
	$uLoc=null;

	$uName = $_POST['uniName'];
	$uLoc = $_POST['location'];

	$insert = "INSERT INTO university(universityName,universityLocation) values('$uName', '$uLoc')";
	mysqli_query($con, $insert);
    echo $uName;
?>
    <!-- <script>
        alert("Successfully Done....!!!");
        window.location = 'admin.php';
    </script> -->
