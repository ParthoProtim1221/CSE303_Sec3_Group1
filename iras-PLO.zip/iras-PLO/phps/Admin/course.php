<?php
    include '../../connection.php';

    $courseID =  $_POST['courseID'];
    $name =  $_POST['name'];
    $noOfCredit = $_POST['noOfCredit'];
    $description = $_POST['description'];
    $program = $_POST['program'];
    $pro = $_POST['pro'];
    $pri = $_POST['pri'];
    
    $insert = "INSERT INTO course(courseID, courseName, noOfCredit, courseDescription, programID, prequisiteCourseID1, prequisiteCourseID2) 
                values('$courseID','$name', '$noOfCredit','$description','$program','$pro','$pri')";
	mysqli_query($con, $insert);

?>
<script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>