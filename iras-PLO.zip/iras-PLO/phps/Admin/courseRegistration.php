<?php
include '../../connection.php';
$r = $_POST['status'];
$registrion = "UPDATE activeness
                SET status = '$r'
                WHERE name = 'registration'";
mysqli_query($con, $registrion);

?>

<script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>