<?php
    include '../connection.php';
    $idNo = isset($_POST['idNo']) ? $_POST['idNo'] : null;
    $pass = $_POST['pass'];
    if (strlen($idNo)=='4'){

        $q = "SELECT * FROM faculty WHERE facultyID='$idNo'";
        $query = mysqli_query($con, $q);
        $t = $query->fetch_assoc();
        $travese = mysqli_num_rows($query);
        
        $q1 = "SELECT facultyIDInCharge FROM department WHERE facultyIDInCharge ='$idNo'";
        $query1 = mysqli_query($con, $q1);
        $t1 = $query1->fetch_assoc();
        $travese1 = mysqli_num_rows($query1);
        
        $_SESSION['name'] = $t['facultyName'];
        $_SESSION['id'] = $t['facultyID'];
        if($travese == 1 && $travese1 == 1 && $t['facultyID'] == $pass)
            header("Location: Head/dashboard_Head.php");
        else if($travese && $t['facultyID'] == $pass)
            header("Location: Faculty/dashboard_Faculty.php");
        else{
            ?>
                <script>
                    alert("Error on ID!");
                    window.location = "../index.php";
                </script>
            <?php
        }
    }
    if (strlen($idNo)=='7'){

        $q = "SELECT * FROM student WHERE studentID='$idNo'";
        $query = mysqli_query($con, $q);
        $t = $query->fetch_assoc();
        $travese = mysqli_num_rows($query);
    
        $_SESSION['name'] = $t['fname']." ".$t['lname'];
        $_SESSION['id'] = $t['studentID'];

        if($travese == 1 && $t['studentID'] == $pass)
            header("Location: Student/dashboard_Student.php");
        else{
            ?>
            <script>
            alert("Error on ID!");
            window.location = "../index.php";
            </script>
            <?php
        }
    }
    elseif($idNo == "Admin" && $pass == "admin"){
        header("Location: Admin/admin.php");
    }
    elseif($idNo == "University" && $pass == "uadmin"){
        header("Location: Admin/uadmin.php");
    }
    else{
        ?>
        <script>
        alert("Error on ID!");
        window.location = "../index.php";
        </script>
        <?php
    }
?>