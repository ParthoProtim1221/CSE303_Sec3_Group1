<?php

//$coArr = isset($_POST['mytext']) ? $_POST['mytext'] : null;
$coArr = $_POST['mytext'];
//$poSelectorArr = array();
//echo $coArr;
//$coArr = implode(": ", $_POST['mytext']);

echo "<br>Total COs along with their PLOs: <br>";

if (!empty($coArr)) {
    for ($i = 0; $i < count($coArr); $i++) {
        echo ($i + 1) . ". " . $coArr[$i]. " PLOs: ";
        $name = "PLO_CO" . (string)($i + 1);
        //array_push($poSelectorArr, $_POST[$name]);
        for ($j = 0; $j < count($_POST[$name]); $j++)
            echo $_POST[$name][$j] . ",   ";
            echo "<br>";
    }
} else {
    echo "NULL";
}
