<?php
//include './phps/conn.php';
session_start();

$email = null;
$pass = null;
$foundEmail = "adad";

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/logInStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="./images/logo1.png">
    <!--<script src="../bootstrap/js/bootstrap.min.js"></script>-->
    <script src="./scripts/jquery.min.js"></script>

</head>

<body>
<?php
//include './phps/navBar.html';
?>
    <div class="wrapper fadeInDown">
        <div id="formContent">
        <h2><em>Sign in to your account</em></h2>
            <!-- Tabs Titles -->

            <!-- Icon -->
            <!-- <div class="fadeIn first">
                <img src="./images/logInLogo.png" />
            </div> -->

            <!-- Login Form -->
            <form action="./phps/loader.php" method="POST">
                <input type="text" id="login" class="fadeIn second" name="idNo" placeholder="Login ID" required>
                <input type="password" id="password" class="fadeIn third" name="pass" placeholder="password" required>
                <input type="submit" name="done" class="fadeIn fourth" value="Log In"> <br>
                <?php
                if ($foundEmail == null) {
                ?><p style="color: red;">Incorrect username or password!</p>
                <?php
                }
                ?>
                
            </form>



            <!-- Remind Passowrd -->
            <div id="formFooter">
                <a class="underlineHover" href="#">Forgot Password?</a>
            </div>

        </div>
    </div>
</body>

</html>